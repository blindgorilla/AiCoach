"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { sports } from "../utils/sports"

type Completion = {
  sport: string
  count: number
}

type CompletionTrackerProps = {
  events: Array<{
    sport: string
    completed: boolean
  }>
}

export default function CompletionTracker({ events }: CompletionTrackerProps) {
  const [completions, setCompletions] = useState<Completion[]>([])

  useEffect(() => {
    const completedEvents = events.filter((event) => event.completed)
    const sportCounts = completedEvents.reduce(
      (acc, event) => {
        acc[event.sport] = (acc[event.sport] || 0) + 1
        return acc
      },
      {} as Record<string, number>,
    )

    const newCompletions = sports
      .map((sport) => ({
        sport,
        count: sportCounts[sport.toLowerCase()] || 0,
      }))
      .filter((completion) => completion.count > 0)

    setCompletions(newCompletions)
  }, [events])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Completed Sessions by Sport</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2">
          {completions.map((completion) => (
            <li key={completion.sport} className="flex justify-between items-center">
              <span className="font-medium">{completion.sport}</span>
              <span className="bg-primary text-primary-foreground px-2 py-1 rounded-full text-sm">
                {completion.count}
              </span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}

