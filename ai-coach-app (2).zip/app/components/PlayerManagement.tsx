"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { sports } from "../utils/sports"

type Player = {
  id: number
  name: string
  sport: string
  color: string
}

export default function PlayerManagement() {
  const [players, setPlayers] = useState<Player[]>([])
  const [newPlayer, setNewPlayer] = useState({ name: "", sport: "", color: "" })

  const addPlayer = () => {
    if (newPlayer.name && newPlayer.sport && newPlayer.color) {
      setPlayers([...players, { ...newPlayer, id: Date.now() }])
      setNewPlayer({ name: "", sport: "", color: "" })
    }
  }

  const deletePlayer = (id: number) => {
    setPlayers(players.filter((player) => player.id !== id))
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h2 className="text-2xl font-bold mb-4">Player Management</h2>
      <div className="space-y-4 mb-4">
        <Input
          placeholder="Player Name"
          value={newPlayer.name}
          onChange={(e) => setNewPlayer({ ...newPlayer, name: e.target.value })}
        />
        <Select onValueChange={(value) => setNewPlayer({ ...newPlayer, sport: value })}>
          <SelectTrigger>
            <SelectValue placeholder="Select Sport" />
          </SelectTrigger>
          <SelectContent>
            {sports.map((sport) => (
              <SelectItem key={sport} value={sport.toLowerCase()}>
                {sport}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Input
          type="color"
          value={newPlayer.color}
          onChange={(e) => setNewPlayer({ ...newPlayer, color: e.target.value })}
        />
        <Button onClick={addPlayer}>Add Player</Button>
      </div>
      <ul className="space-y-2">
        {players.map((player) => (
          <li key={player.id} className="flex justify-between items-center">
            <span>
              {player.name} - {player.sport}
            </span>
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 rounded-full" style={{ backgroundColor: player.color }}></div>
              <Button variant="destructive" onClick={() => deletePlayer(player.id)}>
                Delete
              </Button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}

