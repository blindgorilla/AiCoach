"use client"

import { useState } from "react"
import { Calendar, momentLocalizer } from "react-big-calendar"
import moment from "moment"
import "react-big-calendar/lib/css/react-big-calendar.css"
import { Button } from "@/components/ui/button"
import { sports } from "../utils/sports"

// Initialize localizer
const localizer = momentLocalizer(moment)

type Event = {
  id: number
  title: string
  start: Date
  end: Date
  player: string
  sport: string
  completed: boolean
}

// Sample data (replace with actual data from your backend)
const initialEvents: Event[] = [
  {
    id: 1,
    title: "Tennis with John",
    start: new Date(2023, 5, 1, 10, 0),
    end: new Date(2023, 5, 1, 11, 0),
    player: "John",
    sport: "tennis",
    completed: false,
  },
  {
    id: 2,
    title: "Basketball with Sarah",
    start: new Date(2023, 5, 2, 14, 0),
    end: new Date(2023, 5, 2, 15, 0),
    player: "Sarah",
    sport: "basketball",
    completed: false,
  },
]

export default function WeeklySchedule({ onEventsChange }: { onEventsChange: (events: Event[]) => void }) {
  const [myEvents, setMyEvents] = useState<Event[]>(initialEvents)

  const setMyEventsAndNotify = (newEvents: Event[]) => {
    setMyEvents(newEvents)
    onEventsChange(newEvents)
  }

  const handleSelectSlot = ({ start, end }) => {
    const title = window.prompt("New session name")
    if (title) {
      const sport = window.prompt(`Sport (${sports.join(", ")})`)
      if (sport && sports.map((s) => s.toLowerCase()).includes(sport.toLowerCase())) {
        const player = window.prompt("Player name")
        setMyEventsAndNotify([
          ...myEvents,
          {
            id: Date.now(),
            title,
            start,
            end,
            player,
            sport: sport.toLowerCase(),
            completed: false,
          },
        ])
      } else {
        alert("Please enter a valid sport from the list.")
      }
    }
  }

  const handleSelectEvent = (event: Event) => {
    const isCompleted = window.confirm(`Mark "${event.title}" as completed?`)
    if (isCompleted) {
      setMyEventsAndNotify(myEvents.map((e) => (e.id === event.id ? { ...e, completed: true } : e)))
    }
  }

  const eventStyleGetter = (event: Event) => {
    const sportIndex = sports.findIndex((s) => s.toLowerCase() === event.sport.toLowerCase())
    const hue = (sportIndex * 137.5) % 360 // Use golden ratio to distribute colors
    const backgroundColor = `hsl(${hue}, 70%, 50%)`
    const style: React.CSSProperties = {
      backgroundColor,
      borderRadius: "5px",
      opacity: event.completed ? 0.6 : 1,
      color: "white",
      border: "none",
      display: "block",
    }
    return { style }
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h2 className="text-2xl font-bold mb-4">Weekly Schedule</h2>
      <div className="h-[600px]">
        <Calendar
          localizer={localizer}
          events={myEvents}
          startAccessor="start"
          endAccessor="end"
          style={{ height: "100%" }}
          onSelectSlot={handleSelectSlot}
          onSelectEvent={handleSelectEvent}
          selectable
          eventPropGetter={eventStyleGetter}
        />
      </div>
    </div>
  )
}

