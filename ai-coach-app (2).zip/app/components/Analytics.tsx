"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts"

// Sample data (replace with actual data from your backend)
const data = [
  { name: "Mon", hours: 4 },
  { name: "Tue", hours: 6 },
  { name: "Wed", hours: 5 },
  { name: "Thu", hours: 7 },
  { name: "Fri", hours: 3 },
  { name: "Sat", hours: 8 },
  { name: "Sun", hours: 2 },
]

export default function Analytics() {
  const totalHours = data.reduce((sum, day) => sum + day.hours, 0)

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h2 className="text-2xl font-bold mb-4">Analytics</h2>
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>Total Hours Worked This Week</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-3xl font-bold">{totalHours} hours</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Hours Worked by Day</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data}>
              <XAxis dataKey="name" />
              <YAxis />
              <Bar dataKey="hours" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  )
}

