"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

type Transaction = {
  id: number
  type: "income" | "expense"
  amount: number
  description: string
}

export default function FinancialTracking() {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [newTransaction, setNewTransaction] = useState({ type: "income", amount: "", description: "" })

  const addTransaction = () => {
    if (newTransaction.amount && newTransaction.description) {
      setTransactions([
        ...transactions,
        { ...newTransaction, id: Date.now(), amount: Number.parseFloat(newTransaction.amount) },
      ])
      setNewTransaction({ type: "income", amount: "", description: "" })
    }
  }

  const totalIncome = transactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)
  const totalExpenses = transactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)
  const netProfit = totalIncome - totalExpenses

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h2 className="text-2xl font-bold mb-4">Financial Tracking</h2>
      <div className="space-y-4 mb-4">
        <select
          className="w-full p-2 border rounded"
          value={newTransaction.type}
          onChange={(e) => setNewTransaction({ ...newTransaction, type: e.target.value as "income" | "expense" })}
        >
          <option value="income">Income</option>
          <option value="expense">Expense</option>
        </select>
        <Input
          type="number"
          placeholder="Amount"
          value={newTransaction.amount}
          onChange={(e) => setNewTransaction({ ...newTransaction, amount: e.target.value })}
        />
        <Input
          placeholder="Description"
          value={newTransaction.description}
          onChange={(e) => setNewTransaction({ ...newTransaction, description: e.target.value })}
        />
        <Button onClick={addTransaction}>Add Transaction</Button>
      </div>
      <div className="grid grid-cols-3 gap-4 mb-4">
        <Card>
          <CardHeader>
            <CardTitle>Total Income</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-600">${totalIncome.toFixed(2)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Total Expenses</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-red-600">${totalExpenses.toFixed(2)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Net Profit</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-blue-600">${netProfit.toFixed(2)}</p>
          </CardContent>
        </Card>
      </div>
      <ul className="space-y-2">
        {transactions.map((transaction) => (
          <li key={transaction.id} className="flex justify-between items-center">
            <span>{transaction.description}</span>
            <span className={transaction.type === "income" ? "text-green-600" : "text-red-600"}>
              ${transaction.amount.toFixed(2)}
            </span>
          </li>
        ))}
      </ul>
    </div>
  )
}

