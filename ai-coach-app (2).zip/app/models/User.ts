export interface User {
  id: string
  username: string
  email: string
  password: string // In a real app, this should be hashed
}

// This is a mock database. In a real app, you'd use a proper database.
export const users: User[] = []

