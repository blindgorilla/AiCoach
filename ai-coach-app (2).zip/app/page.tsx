import { redirect } from "next/navigation"

export default function Home() {
  // Check if user is logged in (you'd typically do this server-side)
  const isLoggedIn = false // Replace with actual auth check

  if (isLoggedIn) {
    redirect("/dashboard")
  }

  return (
    <div className="text-center">
      <h1 className="text-4xl font-bold mb-4">Welcome to AI Coach App</h1>
      <p className="mb-4">Please login or register to access your dashboard.</p>
      <div className="space-x-4">
        <a href="/login" className="text-blue-500 hover:underline">
          Login
        </a>
        <a href="/register" className="text-blue-500 hover:underline">
          Register
        </a>
      </div>
    </div>
  )
}

