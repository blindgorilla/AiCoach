"use client"

import { useState } from "react"
import { Calendar, momentLocalizer } from "react-big-calendar"
import moment from "moment"
import "react-big-calendar/lib/css/react-big-calendar.css"

const localizer = momentLocalizer(moment)

export default function CalendarPage() {
  const [events, setEvents] = useState([
    {
      title: "Team Training",
      start: new Date(2023, 5, 1, 10, 0),
      end: new Date(2023, 5, 1, 12, 0),
    },
    {
      title: "One-on-One Session",
      start: new Date(2023, 5, 3, 14, 0),
      end: new Date(2023, 5, 3, 15, 30),
    },
  ])

  const handleSelectSlot = ({ start, end }) => {
    const title = window.prompt("New event name")
    if (title) {
      setEvents([
        ...events,
        {
          start,
          end,
          title,
        },
      ])
    }
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Calendar</h1>
      <div style={{ height: "500px" }}>
        <Calendar
          localizer={localizer}
          events={events}
          startAccessor="start"
          endAccessor="end"
          onSelectSlot={handleSelectSlot}
          selectable
        />
      </div>
    </div>
  )
}

