"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/supabase"

export default function DashboardPage() {
  const [stats, setStats] = useState([
    { title: "Total Sessions", value: "0" },
    { title: "Active Players", value: "0" },
    { title: "This Month's Earnings", value: "$0" },
    { title: "Completion Rate", value: "0%" },
  ])

  const [recentActivity, setRecentActivity] = useState([])

  useEffect(() => {
    const fetchDashboardData = async () => {
      // Fetch stats
      const { data: sessionsData, error: sessionsError } = await supabase.from("sessions").select("*")

      const { data: playersData, error: playersError } = await supabase.from("players").select("*").eq("active", true)

      const { data: earningsData, error: earningsError } = await supabase
        .from("payments")
        .select("amount")
        .gte("created_at", new Date(new Date().setDate(1)).toISOString())

      if (!sessionsError && !playersError && !earningsError) {
        const totalSessions = sessionsData.length
        const activePlayers = playersData.length
        const monthlyEarnings = earningsData.reduce((sum, payment) => sum + payment.amount, 0)
        const completionRate = (sessionsData.filter((session) => session.completed).length / totalSessions) * 100

        setStats([
          { title: "Total Sessions", value: totalSessions.toString() },
          { title: "Active Players", value: activePlayers.toString() },
          { title: "This Month's Earnings", value: `$${monthlyEarnings.toFixed(2)}` },
          { title: "Completion Rate", value: `${completionRate.toFixed(0)}%` },
        ])
      }

      // Fetch recent activity
      const { data: activityData, error: activityError } = await supabase
        .from("activity")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(5)

      if (!activityError) {
        setRecentActivity(activityData)
      }
    }

    fetchDashboardData()
  }, [])

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Welcome to Your Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>
      <div className="mt-8">
        <h2 className="text-2xl font-bold mb-4">Recent Activity</h2>
        <Card>
          <CardContent className="p-0">
            <ul className="divide-y divide-gray-200">
              {recentActivity.map((activity: any) => (
                <li key={activity.id} className="p-4 hover:bg-gray-50">
                  {activity.description}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

