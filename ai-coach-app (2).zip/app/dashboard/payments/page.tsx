"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function PaymentsPage() {
  const [transactions, setTransactions] = useState([
    { id: 1, date: "2023-06-01", description: "Team Training Session", amount: 150 },
    { id: 2, date: "2023-06-03", description: "One-on-One Coaching", amount: 75 },
    { id: 3, date: "2023-06-05", description: "Group Workshop", amount: 200 },
  ])

  const [newTransaction, setNewTransaction] = useState({ date: "", description: "", amount: "" })

  const handleAddTransaction = (e: React.FormEvent) => {
    e.preventDefault()
    if (newTransaction.date && newTransaction.description && newTransaction.amount) {
      setTransactions([
        ...transactions,
        { id: Date.now(), ...newTransaction, amount: Number.parseFloat(newTransaction.amount) },
      ])
      setNewTransaction({ date: "", description: "", amount: "" })
    }
  }

  const totalEarnings = transactions.reduce((sum, transaction) => sum + transaction.amount, 0)

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Payments</h1>
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Total Earnings</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-3xl font-bold">${totalEarnings.toFixed(2)}</p>
        </CardContent>
      </Card>
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Add New Transaction</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleAddTransaction} className="space-y-4">
            <Input
              type="date"
              value={newTransaction.date}
              onChange={(e) => setNewTransaction({ ...newTransaction, date: e.target.value })}
              required
            />
            <Input
              placeholder="Description"
              value={newTransaction.description}
              onChange={(e) => setNewTransaction({ ...newTransaction, description: e.target.value })}
              required
            />
            <Input
              type="number"
              placeholder="Amount"
              value={newTransaction.amount}
              onChange={(e) => setNewTransaction({ ...newTransaction, amount: e.target.value })}
              required
            />
            <Button type="submit">Add Transaction</Button>
          </form>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="divide-y divide-gray-200">
            {transactions.map((transaction) => (
              <li key={transaction.id} className="py-4 flex justify-between">
                <div>
                  <p className="font-medium">{transaction.description}</p>
                  <p className="text-sm text-gray-500">{transaction.date}</p>
                </div>
                <p className="font-medium">${transaction.amount.toFixed(2)}</p>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

