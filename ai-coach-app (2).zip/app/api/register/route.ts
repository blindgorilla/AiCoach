import { NextResponse } from "next/server"
import { users, type User } from "../../models/User"

export async function POST(request: Request) {
  const { username, email, password } = await request.json()

  if (users.some((u) => u.email === email)) {
    return NextResponse.json({ message: "User already exists" }, { status: 400 })
  }

  const newUser: User = {
    id: Date.now().toString(),
    username,
    email,
    password, // In a real app, you should hash this password
  }

  users.push(newUser)

  return NextResponse.json({ message: "User registered successfully" })
}

