import { NextResponse } from "next/server"
import { users } from "../../models/User"
import { cookies } from "next/headers"

export async function POST(request: Request) {
  const { email, password } = await request.json()
  const user = users.find((u) => u.email === email && u.password === password)

  if (user) {
    // Set a session cookie
    cookies().set("session", user.id, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 60 * 60 * 24 * 7, // 1 week
      path: "/",
    })

    return NextResponse.json({ message: "Login successful", redirect: "/onboarding" })
  } else {
    return NextResponse.json({ message: "Login failed" }, { status: 401 })
  }
}

