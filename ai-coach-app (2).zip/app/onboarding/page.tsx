"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function OnboardingPage() {
  const [currentStep, setCurrentStep] = useState(0)
  const router = useRouter()

  const steps = [
    {
      title: "Welcome to AI Coach",
      description: "Let's get you started with your personalized coaching experience.",
    },
    {
      title: "Weekly Schedule",
      description: "Use the calendar to schedule your coaching sessions and track your progress.",
    },
    {
      title: "Player Management",
      description: "Add and manage your players, assigning them to specific sports and sessions.",
    },
    {
      title: "Financial Tracking",
      description: "Keep track of your income and expenses related to your coaching activities.",
    },
    {
      title: "Analytics",
      description: "View insights about your coaching performance and player progress.",
    },
  ]

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      router.push("/dashboard")
    }
  }

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-100">
      <Card className="w-[450px]">
        <CardHeader>
          <CardTitle>{steps[currentStep].title}</CardTitle>
          <CardDescription>{steps[currentStep].description}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center mb-4">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`w-3 h-3 rounded-full mx-1 ${index === currentStep ? "bg-blue-500" : "bg-gray-300"}`}
              />
            ))}
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button
            variant="outline"
            onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
            disabled={currentStep === 0}
          >
            Previous
          </Button>
          <Button onClick={handleNext}>{currentStep === steps.length - 1 ? "Get Started" : "Next"}</Button>
        </CardFooter>
      </Card>
    </div>
  )
}

