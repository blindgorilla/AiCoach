import "./globals.css"
import { Inter } from "next/font/google"
import Link from "next/link"
import { cookies } from "next/headers"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "AI Coach App",
  description: "Manage your coaching schedule, finances, and performance",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const session = cookies().get("session")

  return (
    <html lang="en">
      <body className={inter.className}>
        {!session && (
          <nav className="bg-white shadow-md p-4">
            <div className="container mx-auto flex justify-between items-center">
              <Link href="/" className="text-xl font-bold">
                AI Coach App
              </Link>
              <div className="space-x-4">
                <Link href="/login" className="text-blue-500 hover:underline">
                  Login
                </Link>
                <Link href="/register" className="text-blue-500 hover:underline">
                  Register
                </Link>
              </div>
            </div>
          </nav>
        )}
        <main className={session ? "" : "container mx-auto mt-8 px-4"}>{children}</main>
      </body>
    </html>
  )
}

